<?php

return [

    'single' => [

        'label' => 'Parçala',

        'modal' => [

            'heading' => ':label parçala',

            'actions' => [

                'dissociate' => [
                    'label' => 'Parçala',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Parçalandı',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Seçiləni parçala',

        'modal' => [

            'heading' => ':label seçiləni parçala',

            'actions' => [

                'dissociate' => [
                    'label' => 'Seçiləni parçala',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Parçalandı',
            ],

        ],

    ],

];
