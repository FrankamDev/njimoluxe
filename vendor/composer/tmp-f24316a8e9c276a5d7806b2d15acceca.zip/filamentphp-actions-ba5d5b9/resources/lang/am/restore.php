<?php

return [

    'single' => [

        'label' => 'እነበረበት መልስ',
        'modal' => [

            'heading' => ':labeln መልስ',
            'actions' => [

                'restore' => [

                    'label' => 'እነበረበት መልስ',
                ],
            ],
        ],
        'notifications' => [

            'restored' => [

                'title' => 'ወደነበረበት ተመልሷል',
            ],
        ],
    ],
    'multiple' => [

        'label' => 'የተመረጡትን መልስ',
        'modal' => [

            'heading' => 'የተመረጡት :labelን መልስ',
            'actions' => [

                'restore' => [

                    'label' => 'እነበረበት መልስ',
                ],
            ],
        ],
        'notifications' => [

            'restored' => [

                'title' => 'ወደነበረበት ተመልሷል',
            ],
        ],
    ],
];
