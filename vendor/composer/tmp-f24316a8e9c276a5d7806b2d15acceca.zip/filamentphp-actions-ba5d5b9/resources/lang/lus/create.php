<?php

return [

    'single' => [

        'label' => ':Label siamna',

        'modal' => [

            'heading' => ':Label siamna',

            'actions' => [

                'create' => [
                    'label' => 'Siamna',
                ],

                'create_another' => [
                    'label' => 'Pakhat siama adang siam lehna',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'A thar siam ani.',
            ],

        ],

    ],

];
