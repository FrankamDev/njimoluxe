<?php

return [

    'single' => [

        'label' => 'Phelhna',

        'modal' => [

            'heading' => ':Label Phelhna',

            'actions' => [

                'dissociate' => [
                    'label' => 'Phelhna',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Phelh a ni e.',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Thlan ho phelh thenna',

        'modal' => [

            'heading' => ':Label thlan ho phelh thenna',

            'actions' => [

                'dissociate' => [
                    'label' => 'Phelhna',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Phelh a ni e.',
            ],

        ],

    ],

];
