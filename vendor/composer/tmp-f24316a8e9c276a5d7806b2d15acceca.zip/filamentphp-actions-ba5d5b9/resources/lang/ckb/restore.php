<?php

return [

    'single' => [

        'label' => 'گەڕاندنەوە',

        'modal' => [

            'heading' => 'گەڕاندنەوەی :label',

            'actions' => [

                'restore' => [
                    'label' => 'گەڕاندنەوە',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'گەڕێندراوەیەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'گەڕاندنەوەی هەڵبژێردراوەکان',

        'modal' => [

            'heading' => 'گەڕاندنەوەی هەڵبژێردراوەکانی :label',

            'actions' => [

                'restore' => [
                    'label' => 'گەڕاندنەوە',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'گەڕێندراوەیەوە',
            ],

        ],

    ],

];
