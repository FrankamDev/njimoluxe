<?php

return [

    'throttled' => [
        'title' => 'יותר מדי ניסיונות',
        'body' => 'אנא נסה שוב בעוד :seconds שניות.',
    ],

];
