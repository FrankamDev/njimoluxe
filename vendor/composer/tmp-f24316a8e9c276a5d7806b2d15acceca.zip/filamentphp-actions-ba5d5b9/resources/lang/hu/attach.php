<?php

return [

    'single' => [

        'label' => 'Csatolás',

        'modal' => [

            'heading' => ':label csatolása',

            'fields' => [

                'record_id' => [
                    'label' => 'Elemek',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Csatolás',
                ],

                'attach_another' => [
                    'label' => 'Mentés és új csatolása',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Csatolva',
            ],

        ],

    ],

];
