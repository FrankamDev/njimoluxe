<?php

return [

    'confirmation' => 'დარწმუნებული ხართ, რომ გსურთ ამის გაკეთება?',

    'actions' => [

        'cancel' => [
            'label' => 'გაუქმება',
        ],

        'confirm' => [
            'label' => 'დადასტურება',
        ],

        'submit' => [
            'label' => 'დადასტურება',
        ],

    ],

];
