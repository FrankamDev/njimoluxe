<?php

return [

    'single' => [

        'label' => 'დათვალიერება',

        'modal' => [

            'heading' => 'ათვალიერებთ :label',

            'actions' => [

                'close' => [
                    'label' => 'დახურვა',
                ],

            ],

        ],

    ],

];
