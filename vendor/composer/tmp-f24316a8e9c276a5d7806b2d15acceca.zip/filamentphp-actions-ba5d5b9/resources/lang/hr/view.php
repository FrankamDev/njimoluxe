<?php

return [

    'single' => [

        'label' => 'Pregledaj',

        'modal' => [

            'heading' => 'Pregled :label',

            'actions' => [

                'close' => [
                    'label' => 'Zatvori',
                ],

            ],

        ],

    ],

];
