<?php

return [

    'single' => [

        'label' => 'سڕینەوەی بەهێز',

        'modal' => [

            'heading' => 'سڕینەوەی بەهێزی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'سڕینەوەی بەهێزی دیاریکراوەکان',

        'modal' => [

            'heading' => 'سڕینەوەی بەهێزی دیاریکراوەکانی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

];
