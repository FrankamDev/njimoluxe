<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Prikaži :count manje',
                'expand_list' => 'Prikaži :count više',
            ],

            'more_list_items' => 'i :count više',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Ključ',
                ],

                'value' => [
                    'label' => 'Vrednost',
                ],

            ],

            'placeholder' => 'Bez unosa',

        ],

    ],

];
