<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'نمایش :count کمتر',
                'expand_list' => 'نمایش :count بیشتر',
            ],

            'more_list_items' => 'و :count مورد دیگر',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'کلید',
                ],

                'value' => [
                    'label' => 'مقدار',
                ],

            ],

            'placeholder' => 'بدون ورودی',

        ],

    ],
];
