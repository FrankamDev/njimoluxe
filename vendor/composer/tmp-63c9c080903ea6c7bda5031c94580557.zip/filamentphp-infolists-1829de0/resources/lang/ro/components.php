<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Afișează cu :count mai puțin',
                'expand_list' => 'Afișează cu :count mai mult',
            ],

            'more_list_items' => 'și alte :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Cheie',
                ],

                'value' => [
                    'label' => 'Valoare',
                ],

            ],

            'placeholder' => 'Nu există intrări',

        ],

    ],

];
