<?php

return [

    'actions' => [

        'filter' => [
            'label' => '필터',
        ],

    ],

];
