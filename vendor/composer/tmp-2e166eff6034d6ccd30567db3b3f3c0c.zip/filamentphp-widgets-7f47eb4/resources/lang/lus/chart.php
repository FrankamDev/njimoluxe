<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Thlit fîmna',
        ],

    ],

];
