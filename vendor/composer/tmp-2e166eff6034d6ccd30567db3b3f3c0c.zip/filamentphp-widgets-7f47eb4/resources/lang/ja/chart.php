<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'フィルター',
        ],

    ],

];
