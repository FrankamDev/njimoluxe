<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filteren',
        ],

    ],

    'filters' => [

        'actions' => [

            'apply' => [
                'label' => 'Toepassen',
            ],

            'reset' => [
                'label' => 'Resetten',
            ],

        ],

    ],

];
