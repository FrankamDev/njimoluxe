<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtro',
        ],

    ],

];
