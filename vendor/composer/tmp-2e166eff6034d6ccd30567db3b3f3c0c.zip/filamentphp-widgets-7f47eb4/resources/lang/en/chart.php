<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filter',
        ],

    ],

    'filters' => [

        'actions' => [

            'apply' => [
                'label' => 'Apply',
            ],

            'reset' => [
                'label' => 'Reset',
            ],

        ],

    ],

];
