<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Фильтр',
        ],

    ],

];
