<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'Filtruoti',
        ],

    ],

];
