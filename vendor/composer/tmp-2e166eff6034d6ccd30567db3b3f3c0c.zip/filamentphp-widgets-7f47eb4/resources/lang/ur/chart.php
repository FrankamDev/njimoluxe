<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'فلٹر کریں',
        ],

    ],

];
