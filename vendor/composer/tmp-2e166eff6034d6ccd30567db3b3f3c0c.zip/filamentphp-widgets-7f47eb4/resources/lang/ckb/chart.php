<?php

return [

    'actions' => [

        'filter' => [
            'label' => 'پاڵاوتن',
        ],

    ],

];
