<?php

return [

    'messages' => [
        'uploading_file' => 'Uploading file...',
    ],

];
