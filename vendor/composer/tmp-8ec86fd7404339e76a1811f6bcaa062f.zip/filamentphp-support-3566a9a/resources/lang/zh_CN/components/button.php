<?php

return [

    'messages' => [
        'uploading_file' => '文件上传中...',
    ],

];
