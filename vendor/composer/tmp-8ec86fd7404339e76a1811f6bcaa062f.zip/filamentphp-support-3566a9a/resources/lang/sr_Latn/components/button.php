<?php

return [

    'messages' => [
        'uploading_file' => 'Šaljem datoteku...',
    ],

];
