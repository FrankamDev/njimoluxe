<?php

return [

    'messages' => [

        'uploading_file' => 'درحال آپلود فایل...',

    ],

];
