<?php

return [

    'actions' => [

        'close' => [
            'label' => 'بند کریں',
        ],

    ],

];
