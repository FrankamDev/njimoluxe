<?php

return [

    'messages' => [
        'copied' => 'کاپی ہو گیا',
    ],

];
