<?php

return [

    'actions' => [

        'close' => [

            'label' => 'ዝጋ',
        ],
    ],
];
