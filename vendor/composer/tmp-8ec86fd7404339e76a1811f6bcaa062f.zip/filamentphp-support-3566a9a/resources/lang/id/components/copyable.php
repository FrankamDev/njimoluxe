<?php

return [

    'messages' => [
        'copied' => 'Berhasil disalin',
    ],

];
