<?php

return [

    'messages' => [
        'copied' => 'Lâk chhâwn ani e',
    ],

];
