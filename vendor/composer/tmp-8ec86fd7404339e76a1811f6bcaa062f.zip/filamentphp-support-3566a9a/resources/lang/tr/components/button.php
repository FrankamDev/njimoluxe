<?php

return [

    'messages' => [
        'uploading_file' => 'Dosya yükleniyor...',
    ],

];
