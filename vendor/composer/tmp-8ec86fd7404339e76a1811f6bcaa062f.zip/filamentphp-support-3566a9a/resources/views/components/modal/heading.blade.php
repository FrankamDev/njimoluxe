<h2
    {{ $attributes->class(['fi-modal-heading']) }}
>
    {{ $slot }}
</h2>
