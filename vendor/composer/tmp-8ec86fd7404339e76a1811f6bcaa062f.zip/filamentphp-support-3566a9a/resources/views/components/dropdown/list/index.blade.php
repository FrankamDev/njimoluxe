<div {{ $attributes->class(['fi-dropdown-list']) }}>
    {{ $slot }}
</div>
