<?php

namespace Filament\Tables\Enums;

enum FiltersResetActionPosition
{
    case Header;

    case Footer;
}
