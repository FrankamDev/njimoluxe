<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\DateConstraint\Operators;

class IsBeforeOperator extends \Filament\QueryBuilder\Constraints\DateConstraint\Operators\IsBeforeOperator {}
