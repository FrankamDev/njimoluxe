<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\DateConstraint\Operators;

class IsMonthOperator extends \Filament\QueryBuilder\Constraints\DateConstraint\Operators\IsMonthOperator {}
