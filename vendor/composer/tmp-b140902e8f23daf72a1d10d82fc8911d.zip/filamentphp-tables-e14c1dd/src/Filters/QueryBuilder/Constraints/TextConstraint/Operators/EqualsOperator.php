<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\TextConstraint\Operators;

class EqualsOperator extends \Filament\QueryBuilder\Constraints\TextConstraint\Operators\EqualsOperator {}
