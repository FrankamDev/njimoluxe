<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints;

class NumberConstraint extends \Filament\QueryBuilder\Constraints\NumberConstraint {}
