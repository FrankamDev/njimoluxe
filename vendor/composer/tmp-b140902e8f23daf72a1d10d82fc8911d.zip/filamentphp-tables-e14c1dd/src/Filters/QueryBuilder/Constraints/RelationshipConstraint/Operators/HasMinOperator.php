<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\RelationshipConstraint\Operators;

class HasMinOperator extends \Filament\QueryBuilder\Constraints\RelationshipConstraint\Operators\HasMinOperator {}
