<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints;

class BooleanConstraint extends \Filament\QueryBuilder\Constraints\BooleanConstraint {}
