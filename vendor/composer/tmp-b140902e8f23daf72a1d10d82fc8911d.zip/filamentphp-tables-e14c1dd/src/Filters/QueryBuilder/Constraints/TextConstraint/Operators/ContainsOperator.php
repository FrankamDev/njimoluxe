<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\TextConstraint\Operators;

class ContainsOperator extends \Filament\QueryBuilder\Constraints\TextConstraint\Operators\ContainsOperator {}
