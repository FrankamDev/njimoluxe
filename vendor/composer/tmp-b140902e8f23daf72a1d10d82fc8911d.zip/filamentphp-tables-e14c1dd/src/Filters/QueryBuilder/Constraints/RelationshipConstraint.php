<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints;

class RelationshipConstraint extends \Filament\QueryBuilder\Constraints\RelationshipConstraint {}
