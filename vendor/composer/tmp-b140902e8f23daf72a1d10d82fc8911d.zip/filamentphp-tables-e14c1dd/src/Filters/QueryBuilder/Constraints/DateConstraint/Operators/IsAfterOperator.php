<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\DateConstraint\Operators;

class IsAfterOperator extends \Filament\QueryBuilder\Constraints\DateConstraint\Operators\IsAfterOperator {}
