<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\SelectConstraint\Operators;

class IsOperator extends \Filament\QueryBuilder\Constraints\SelectConstraint\Operators\IsOperator {}
