<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\TextConstraint\Operators;

class StartsWithOperator extends \Filament\QueryBuilder\Constraints\TextConstraint\Operators\StartsWithOperator {}
