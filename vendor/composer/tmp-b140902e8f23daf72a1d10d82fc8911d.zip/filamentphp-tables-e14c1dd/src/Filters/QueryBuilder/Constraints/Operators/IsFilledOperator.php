<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\Operators;

class IsFilledOperator extends \Filament\QueryBuilder\Constraints\Operators\IsFilledOperator {}
