<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\NumberConstraint\Operators;

class IsMinOperator extends \Filament\QueryBuilder\Constraints\NumberConstraint\Operators\IsMinOperator {}
