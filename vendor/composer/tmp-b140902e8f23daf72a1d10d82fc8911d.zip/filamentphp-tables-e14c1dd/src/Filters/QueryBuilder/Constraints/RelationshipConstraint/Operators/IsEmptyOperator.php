<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\RelationshipConstraint\Operators;

class IsEmptyOperator extends \Filament\QueryBuilder\Constraints\RelationshipConstraint\Operators\IsEmptyOperator {}
