<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints\DateConstraint\Operators;

class IsDateOperator extends \Filament\QueryBuilder\Constraints\DateConstraint\Operators\IsDateOperator {}
