<?php

namespace Filament\Tables\Filters\QueryBuilder\Constraints;

class SelectConstraint extends \Filament\QueryBuilder\Constraints\SelectConstraint {}
