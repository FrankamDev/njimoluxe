<?php

return [

    'column_manager' => [

        'heading' => 'Stulpeliai',

        'actions' => [

            'apply' => [
                'label' => 'Taikyti stulpelius',
            ],

            'reset' => [
                'label' => 'Atstatyti',
            ],

        ],

    ],

    'columns' => [

        'actions' => [
            'label' => 'Veiksmas|Veiksmai',
        ],

        'select' => [

            'loading_message' => 'Kraunama...',

            'no_options_message' => 'Nėra galimų parinkčių.',

            'no_search_results_message' => 'Paieškos atitikmenų nėra.',

            'placeholder' => 'Pasirinkite parinktį',

            'searching_message' => 'Ieškoma...',

            'search_prompt' => 'Pradėkite rašyti, kad ieškotumėte...',

        ],

        'text' => [

            'actions' => [
                'collapse_list' => 'Slėpti :count',
                'expand_list' => 'Rodyti dar :count',
            ],

            'more_list_items' => 'ir dar :count',
        ],

    ],

    'fields' => [

        'bulk_select_page' => [
            'label' => 'Pažymėti/atžymėti visus įrašus masiniam veiksmui.',
        ],

        'bulk_select_record' => [
            'label' => 'Pažymėti/atžymėti įrašą :key masiniam veiksmui.',
        ],

        'bulk_select_group' => [
            'label' => 'Pažymėti/atžymėti grupę :title masiniam veiksmui.',
        ],

        'search' => [
            'label' => 'Paieška',
            'placeholder' => 'Paieška',
            'indicator' => 'Paieška',
        ],

    ],

    'summary' => [

        'heading' => 'Santrauka',

        'subheadings' => [
            'all' => 'Viso :label',
            'group' => ':group santrauka',
            'page' => 'Šis puslapis',
        ],

        'summarizers' => [

            'average' => [
                'label' => 'Vidurkis',
            ],

            'count' => [
                'label' => 'Viso',
            ],

            'sum' => [
                'label' => 'Suma',
            ],

        ],

    ],

    'actions' => [

        'disable_reordering' => [
            'label' => 'Pabaik pertvarkyti įrašus',
        ],

        'enable_reordering' => [
            'label' => 'Pertvarkyti įrašus',
        ],

        'filter' => [
            'label' => 'Filtras',
        ],

        'group' => [
            'label' => 'Grupė',
        ],

        'open_bulk_actions' => [
            'label' => 'Atidaryti veiksmus',
        ],

        'column_manager' => [
            'label' => 'Perjungti stulpelius',
        ],

    ],

    'empty' => [

        'heading' => 'Nerasta įrašų',

        'description' => 'Norėdami pradėti, sukurkite :model.',

    ],

    'filters' => [

        'actions' => [

            'apply' => [
                'label' => 'Taikyti filtrus',
            ],

            'remove' => [
                'label' => 'Pašalinti filtrą',
            ],

            'remove_all' => [
                'label' => 'Pašalinti visus filtrus',
                'tooltip' => 'Pašalinti visus filtrus',
            ],

            'reset' => [
                'label' => 'Nustatyti filtrus iš naujo',
            ],

        ],

        'heading' => 'Filtrai',

        'indicator' => 'Aktyvūs filtrai',

        'multi_select' => [
            'placeholder' => 'Visi',
        ],

        'select' => [
            'placeholder' => 'Visi',

            'relationship' => [
                'empty_option_label' => 'Nėra',
            ],
        ],

        'trashed' => [

            'label' => 'Ištrinti įrašai',

            'only_trashed' => 'Tik ištrinti įrašai',

            'with_trashed' => 'Su ištrintais įrašais',

            'without_trashed' => 'Be ištrintų įrašų',

        ],

    ],

    'grouping' => [

        'fields' => [

            'group' => [
                'label' => 'Grupuoti pagal',
            ],

            'direction' => [

                'label' => 'Grupės kryptis',

                'options' => [
                    'asc' => 'Didėjančia tvarka',
                    'desc' => 'Mažėjančia tvarka',
                ],

            ],

        ],

    ],

    'reorder_indicator' => 'Vilkite ir paleiskite įrašų rikiavimui.',

    'selection_indicator' => [

        'selected_count' => '1 įrašas pasirinktas|:count įrašai pasirinkti',

        'actions' => [

            'select_all' => [
                'label' => 'Pažymėti visus :count',
            ],

            'deselect_all' => [
                'label' => 'Atžymėti visus',
            ],

        ],

    ],

    'sorting' => [

        'fields' => [

            'column' => [
                'label' => 'Rūšiuoti pagal',
            ],

            'direction' => [

                'label' => 'Rūšiavimo kryptis',

                'options' => [
                    'asc' => 'Didėjimo tvarka',
                    'desc' => 'Mažėjimo tvarka',
                ],

            ],

        ],

    ],

    'default_model_label' => 'įrašas',
];
